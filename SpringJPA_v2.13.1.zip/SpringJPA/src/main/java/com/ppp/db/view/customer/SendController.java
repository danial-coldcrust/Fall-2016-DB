package com.ppp.db.view.customer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ppp.db.office.OfficeService;
import com.ppp.db.office.OfficeVO;
import com.ppp.db.receipt.ReceiptService;
import com.ppp.db.receipt.ReceiptVO;
import com.ppp.db.send.SendService;
import com.ppp.db.send.SendVO;
import com.ppp.db.staff.StaffService;
import com.ppp.db.staff.StaffVO;

@Controller
@SessionAttributes("send")
public class SendController {
	//@Qualifier(value = "SendDAOJPA")
	@Autowired
	private SendService sendService;
	
	//@Qualifier(value = "OfficeDAOJPA")
	@Autowired
	private OfficeService officeService;
	
	@Autowired
	private ReceiptService receiptService;
	
	@Autowired
	private StaffService staffService;
	
	// 검색 조건 목록 설정
	@ModelAttribute("conditionMap")
	public Map<String, String> searchConditionMap() {
		Map<String, String> conditionMap = new HashMap<String, String>();
		conditionMap.put("처리순번", "SEND_NUM");
		conditionMap.put("물품번호", "ITEM_NUM");
		conditionMap.put("직원번호", "STAFF_NUM");
		conditionMap.put("날짜", "DATE");
		conditionMap.put("시간", "TIME");
		conditionMap.put("물품위치", "ITEM_POSITION");
		conditionMap.put("처리내용", "HANDLING_STATE");
		conditionMap.put("수신자", "RECEIVER_NAME");
		return conditionMap;
	}
	
	@RequestMapping("/insertSend.do")
	public String insertSend(SendVO vo) {
		sendService.insertSend(vo);
		return "getSendList.do";
	}
	@RequestMapping("/updateSend.do")
	public String updateSend(SendVO vo) {
		sendService.updateSend(vo);
		return "getSendList.do";
	}
	/* 수령버튼 눌렀을때 */ 
	@RequestMapping("/acceptSend.do") 
	public String acceptSend(SendVO vo,@RequestParam(value="ofs_num",
			defaultValue="", required=false) String staff_num) {
		String num = vo.getSend_num();
		String[] str = num.split("-");
		int i = Integer.parseInt(str[3]);
		vo.setHandling_state("발송완료");
		sendService.updateSend(vo);
		vo.setStaff_num(staff_num);
		str[3] = Integer.toString(++i);
		vo.setSend_num(str[0]+"-"+str[1]+"-"+str[2]+"-"+str[3]);
		vo.setHandling_state("수령");
		sendService.insertSend(vo);
		return "getSendList.do";
	}
	@RequestMapping("/deleteSend.do")
	public String deleteSend(SendVO vo) {
		sendService.deleteSend(vo);
		return "getSendList.do";
	}
	// /* 발송버튼 눌렀을때 */ 
	@RequestMapping("/posting.do")
	public String posting(SendVO vo, @RequestParam(value="via",
			defaultValue="", required=false) String via,
			@RequestParam(value="ofs_num",
			defaultValue="", required=false) String staff_num) {
		
		String num = vo.getSend_num();
		String[] str = num.split("-");
		int i = Integer.parseInt(str[3]);
		if(vo.getHandling_state().equals("접수")==true){
			vo.setHandling_state("접수완료");
		}
		else if(vo.getHandling_state().equals("수령")==true){
			vo.setHandling_state("수령완료");
		}
		sendService.updateSend(vo);
		str[3] = Integer.toString(++i);
		vo.setSend_num(str[0]+"-"+str[1]+"-"+str[2]+"-"+str[3]);
		vo.setHandling_state("발송");
		vo.setStaff_num(staff_num);
		StringBuffer sb = new StringBuffer(vo.getItem_position());
		sb.replace(0, 1, sb.substring(2, 3));
		sb.replace(2, 3, via);
		vo.setItem_position(sb.toString());

		str = vo.getItem_position().split("-");
		if (str[0].equals(str[1])==true){
			vo.setHandling_state("배송출발");
		}
		sendService.insertSend(vo);
		return "getSendList.do";
	}	
	@RequestMapping("/getSend.do")
	public String getSend(SendVO vo, Model model){
		model.addAttribute("send", sendService.getSend(vo));
		return "getSend.jsp";
	}
	@RequestMapping("/getSendList.do")
	public String getSendList(SendVO vo, Model model){
		OfficeVO test = new OfficeVO();
		test.setOffice_num(1);
		test = officeService.getOffice(test);
		test.setSearchCondition("OFFICE_NUM");
		test.setSearchKeyword("");
		// null check
		if(vo.getSearchCondition() == null) vo.setSearchCondition("SEND_NUM");
		if(vo.getSearchKeyword() == null) vo.setSearchKeyword("");
		// model 정보저장
		model.addAttribute("sendList", sendService.getSendList(vo));
		model.addAttribute("officeList", officeService.getOfficeList(test));
		return "getSendList.jsp";
	}
	   @RequestMapping("/getSendListCustomer.do")
	    public String getSendListCustomer(SendVO vo, Model model){
	       // null check
	       if(vo.getSearchCondition() == null) vo.setSearchCondition("SEND_NUM");
	       if(vo.getSearchKeyword() == null) vo.setSearchKeyword("");
	      
	       List<SendVO> sendList = sendService.getSendList(vo);
	       StaffVO staffVO = new StaffVO();

	       staffVO.setSearchCondition("STAFF_NUM");
	       staffVO.setSearchKeyword("");
	       List<StaffVO> staffList = staffService.getStaffList(staffVO);

	       for(int i = 0; i<sendList.size(); i++){
	          for(int j=0; j<staffList.size(); j++){
	             if(staffList.get(j).getStaff_num().equals(sendList.get(i).getStaff_num())){
	                sendList.get(i).setStaff_num(staffList.get(j).getStaff_name());
	             }
	          }
	       }
	       
	       OfficeVO officeVO = new OfficeVO();
	       officeVO.setSearchCondition("OFFICE_NUM");
	       officeVO.setSearchKeyword("");
	       List<OfficeVO> OfficeList = officeService.getOfficeList(officeVO);
	       
	       for(int i=0; i<sendList.size(); i++){
	    	   String[] ggg = sendList.get(i).getItem_position().split("-");
	    	   for(int j=0; j<OfficeList.size(); j++){
	    		   if(Integer.parseInt(ggg[0]) == OfficeList.get(j).getOffice_num()){
	    			   sendList.get(i).setItem_position(OfficeList.get(j).getOffice_name());
	    		   }
	    	   }
	       }
	       // model 정보저장
	       model.addAttribute("sendListCustomer", sendList);
	       return "getSendListCustomer.jsp";   
	    }
	
	/*비회원 고객이 물품 조회를 할때 목록을 넘겨줌 jsp에*/
	@RequestMapping("/getSendListnoMem.do")
	public String getSendListnoMem(SendVO vo, Model model){
		 // null check
	       if(vo.getSearchCondition() == null) vo.setSearchCondition("SEND_NUM");
	       if(vo.getSearchKeyword() == null) vo.setSearchKeyword("");
	      
	       List<SendVO> sendList = sendService.getSendList(vo);
	       StaffVO staffVO = new StaffVO();

	       staffVO.setSearchCondition("STAFF_NUM");
	       staffVO.setSearchKeyword("");
	       List<StaffVO> staffList = staffService.getStaffList(staffVO);

	       for(int i = 0; i<sendList.size(); i++){
	          for(int j=0; j<staffList.size(); j++){
	             if(staffList.get(j).getStaff_num().equals(sendList.get(i).getStaff_num())){
	                sendList.get(i).setStaff_num(staffList.get(j).getStaff_name());
	             }
	          }
	       }
	       
	       OfficeVO officeVO = new OfficeVO();
	       officeVO.setSearchCondition("OFFICE_NUM");
	       officeVO.setSearchKeyword("");
	       List<OfficeVO> OfficeList = officeService.getOfficeList(officeVO);
	       
	       for(int i=0; i<sendList.size(); i++){
	    	   String[] ggg = sendList.get(i).getItem_position().split("-");
	    	   for(int j=0; j<OfficeList.size(); j++){
	    		   if(Integer.parseInt(ggg[0]) == OfficeList.get(j).getOffice_num()){
	    			   sendList.get(i).setItem_position(OfficeList.get(j).getOffice_name());
	    		   }
	    	   }
	       }
		model.addAttribute("sendListnoMem", sendList);
		return "getSendListnoMem.jsp";
	}

	/* 집배원 수령처리 화면  */
	@RequestMapping("/getSendListDiv.do")
	public String getSendListDiv(SendVO vo, Model model){
		// null check
				if(vo.getSearchCondition() == null) vo.setSearchCondition("SEND_NUM");
				if(vo.getSearchKeyword() == null) vo.setSearchKeyword("");
				// model 정보저장
		model.addAttribute("sendListDiv", sendService.getSendList(vo));
		return "getSendListDiv.jsp";
	}
	
	/* 집배원 수령버튼 눌렀을때 */ 
	@RequestMapping("/complete.do") 
	public String complete(SendVO vo, @RequestParam(value="ofs_num",
			defaultValue="", required=false) String staff_num) {
		
		String num = vo.getSend_num();
		String[] str = num.split("-");
		int i = Integer.parseInt(str[3]);
		vo.setHandling_state("배송출발완료");
		sendService.updateSend(vo);
		vo.setStaff_num(staff_num);
		str[3] = Integer.toString(++i);
		vo.setSend_num(str[0]+"-"+str[1]+"-"+str[2]+"-"+str[3]);
		vo.setHandling_state("배송완료");
		sendService.insertSend(vo);
		
		ReceiptVO receiptVO = new ReceiptVO();
		OfficeVO officeVO = new OfficeVO();
		
		String[] x = vo.getSend_num().split("-");
		String y = x[0]+"-"+x[1]+"-"+x[2];
		receiptVO.setReceipt_num(y);
		receiptVO = receiptService.getReceipt(receiptVO);
		
		if(receiptVO.getPay_type().equals("착불")){
			String a = receiptVO.getStaff_num();
			String[] a_num;
			
			a_num = a.split("-");
			officeVO.setOffice_num(Integer.parseInt(a_num[0]));
			officeVO = officeService.getOffice(officeVO);
			
			int price = officeVO.getTotal_price();
			price += receiptVO.getSend_pay();
			officeVO.setTotal_price(price);
			
			officeService.updateOffice(officeVO);
		}
		return "getSendListDiv.do";
	}
}
