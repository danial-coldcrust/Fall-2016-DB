package com.ppp.db.view.customer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ppp.db.office.OfficeService;
import com.ppp.db.office.OfficeVO;
import com.ppp.db.send.SendService;
import com.ppp.db.send.SendVO;

@Controller
@SessionAttributes("send")
public class SendController {
	
	//@Qualifier(value = "SendDAOJPA")
	@Autowired
	private SendService sendService;
	
	
	//@Qualifier(value = "OfficeDAOJPA")
	@Autowired
	private OfficeService officeService;
	
	// 검색 조건 목록 설정
	@ModelAttribute("conditionMap")
	public Map<String, String> searchConditionMap() {
		Map<String, String> conditionMap = new HashMap<String, String>();
		conditionMap.put("처리순번", "SEND_NUM");
		conditionMap.put("물품번호", "ITEM_NUM");
		conditionMap.put("직원번호", "STAFF_NUM");
		conditionMap.put("날짜", "DATE");
		conditionMap.put("시간", "TIME");
		conditionMap.put("물품위치", "ITEM_POSITION");
		conditionMap.put("처리내용", "HANDLING_STATE");
		conditionMap.put("수신자", "RECEIVER_NAME");
		return conditionMap;
	}
	
	@RequestMapping("/insertSend.do")
	public String insertSend(SendVO vo) {
		sendService.insertSend(vo);
		return "getSendList.do";
	}
	@RequestMapping("/updateSend.do")
	public String updateSend(SendVO vo) {
		sendService.updateSend(vo);
		return "getSendList.do";
	}
	@RequestMapping("/acceptSend.do")
	public String acceptSend(SendVO vo) {
		String num = vo.getSend_num();
		String[] str = num.split("-");
		int i = Integer.parseInt(str[3]);
		vo.setHandling_state("접수(처리완료)");
		sendService.updateSend(vo);
		str[3] = Integer.toString(++i);
		vo.setSend_num(str[0]+"-"+str[1]+"-"+str[2]+"-"+str[3]);
		if(vo.getHandling_state().equals("접수(처리완료)")==true){
			vo.setHandling_state("발송");
		}
		sendService.updateSend(vo);
		return "getSendList.do";
	}
	@RequestMapping("/deleteSend.do")
	public String deleteSend(SendVO vo) {
		sendService.deleteSend(vo);
		return "getSendList.do";
	}
	// 수정해서 삽입할거임 ( 배송처리에서 발송버튼 눌렀을때 )
	@RequestMapping("/posting.do")
	public String posting(SendVO vo, @RequestParam(value="via",
			defaultValue="", required=false) String via,
			@RequestParam(value="ofs_num",
			defaultValue="", required=false) String staff_num) {
		vo.setStaff_num(staff_num);
		vo.setItem_position(via);
		sendService.updateSend(vo);
		return "getSendList.do";
	}
	@RequestMapping("/getSend.do")
	public String getSend(SendVO vo, Model model){
		model.addAttribute("send", sendService.getSend(vo));
		return "getSend.jsp";
	}
	@RequestMapping("/getSendList.do")
	public String getSendList(SendVO vo, Model model){
		OfficeVO test = new OfficeVO();
		test.setOffice_num(1);
		test = officeService.getOffice(test);
		test.setSearchCondition("OFFICE_NUM");
		test.setSearchKeyword("");
		// null check
		if(vo.getSearchCondition() == null) vo.setSearchCondition("SEND_NUM");
		if(vo.getSearchKeyword() == null) vo.setSearchKeyword("");
		// model 정보저장
		model.addAttribute("sendList", sendService.getSendList(vo));
		model.addAttribute("officeList", officeService.getOfficeList(test));
		return "getSendList.jsp";
	}
}
