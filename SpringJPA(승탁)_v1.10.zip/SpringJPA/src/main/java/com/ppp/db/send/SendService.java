package com.ppp.db.send;

import java.util.List;

import com.ppp.db.receipt.ReceiptVO;

public interface SendService {
	public void insertSend(SendVO vo);
	public void updateSend(SendVO vo);
	public void deleteSend(SendVO vo);
	public SendVO getSend(SendVO vo);
	public List<SendVO> getSendList(SendVO vo);
}
