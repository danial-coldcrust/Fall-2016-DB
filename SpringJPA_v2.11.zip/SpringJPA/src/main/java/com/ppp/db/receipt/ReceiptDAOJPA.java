package com.ppp.db.receipt;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
@Repository
public class ReceiptDAOJPA {
	@PersistenceContext
	private EntityManager em;

	public void insertReceipt(ReceiptVO vo) {
		em.persist(vo);
	}

	public void updateReceipt(ReceiptVO vo) {
		em.merge(vo);
	}

	public void deleteReceipt(ReceiptVO vo) {
		em.remove(em.find(ReceiptVO.class, vo.getReceipt_num()));
	}

	public ReceiptVO getReceipt(ReceiptVO vo) {
		return (ReceiptVO) em.find(ReceiptVO.class, vo.getReceipt_num());
	}

	public List<ReceiptVO> getReceiptList(ReceiptVO vo) {
		if (vo.getSearchCondition().equals("RECEIPT_NUM")) {
			return em.createQuery(
					"select b from ReceiptVO b where b.receipt_num like '%'||?1||'%' order by b.receipt_num desc",
					ReceiptVO.class).setParameter(1, vo.getSearchKeyword()).getResultList();
		} else if (vo.getSearchCondition().equals("CUSTOMER_NUM")) {
			return em.createQuery(
					"select b from ReceiptVO b where b.customer_num like '%'||?1||'%' order by b.receipt_num desc",
					ReceiptVO.class).setParameter(1, vo.getSearchKeyword()).getResultList();
		} else if (vo.getSearchCondition().equals("ITEM_NUM")) {
			return em.createQuery(
					"select b from ReceiptVO b where b.item_num like '%'||?1||'%' order by b.receipt_num desc",
					ReceiptVO.class).setParameter(1, vo.getSearchKeyword()).getResultList();
		} else if (vo.getSearchCondition().equals("STAFF_NUM")) {
			return em.createQuery(
					"select b from ReceiptVO b where b.staff_num like '%'||?1||'%' order by b.receipt_num desc",
					ReceiptVO.class).setParameter(1, vo.getSearchKeyword()).getResultList();
		} else if (vo.getSearchCondition().equals("RECEIPT_DATE")) {
			return em.createQuery(
					"select b from ReceiptVO b where b.receipt_date like '%'||?1||'%' order by b.receipt_num desc",
					ReceiptVO.class).setParameter(1, vo.getSearchKeyword()).getResultList();
		} else if (vo.getSearchCondition().equals("SEND_TYPE")) {
			return em.createQuery(
					"select b from ReceiptVO b where b.send_type like '%'||?1||'%' order by b.receipt_num desc",
					ReceiptVO.class).setParameter(1, vo.getSearchKeyword()).getResultList();
		} else if (vo.getSearchCondition().equals("PAY_TYPE")) {
			return em.createQuery(
					"select b from ReceiptVO b where b.pay_type like '%'||?1||'%' order by b.receipt_num desc",
					ReceiptVO.class).setParameter(1, vo.getSearchKeyword()).getResultList();
		} else if (vo.getSearchCondition().equals("SEND_PAY")) {
			return em.createQuery(
					"select b from ReceiptVO b where b.send_pay like '%'||?1||'%' order by b.receipt_num desc",
					ReceiptVO.class).setParameter(1, vo.getSearchKeyword()).getResultList();
		}
		return null;
	}
}
